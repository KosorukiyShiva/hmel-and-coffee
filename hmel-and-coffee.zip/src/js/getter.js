const windowInnerWidth = window.innerWidth
const windowInnerHeight = window.innerHeight

const half_windowInnerWidth = windowInnerWidth/2
const prcnt_windowInnerHeight = Number(windowInnerHeight)/100
const prcnt_windowInnerWidth = Number(windowInnerWidth)/100