const beer_menu_sqr_name_text_1 = document.getElementById('beer_menu_sqr_name_text_1')
const beer_menu_sqr_name_text_2 = document.getElementById('beer_menu_sqr_name_text_2')
const beer_menu_sqr_name_text_3 = document.getElementById('beer_menu_sqr_name_text_3')
const beer_menu_sqr_name_text_4 = document.getElementById('beer_menu_sqr_name_text_4')
const beer_menu_sqr_name_text_5 = document.getElementById('beer_menu_sqr_name_text_5')
const beer_menu_sqr_name_text_6 = document.getElementById('beer_menu_sqr_name_text_6')
const beer_menu_sqr_name_text_7 = document.getElementById('beer_menu_sqr_name_text_7')
const beer_menu_sqr_name_text_8 = document.getElementById('beer_menu_sqr_name_text_8')

const beer_menu_sqr_brewery_text_1 = document.getElementById('beer_menu_sqr_brewery_text_1')
const beer_menu_sqr_brewery_text_2 = document.getElementById('beer_menu_sqr_brewery_text_2')
const beer_menu_sqr_brewery_text_3 = document.getElementById('beer_menu_sqr_brewery_text_3')
const beer_menu_sqr_brewery_text_4 = document.getElementById('beer_menu_sqr_brewery_text_4')
const beer_menu_sqr_brewery_text_5 = document.getElementById('beer_menu_sqr_brewery_text_5')
const beer_menu_sqr_brewery_text_6 = document.getElementById('beer_menu_sqr_brewery_text_6')
const beer_menu_sqr_brewery_text_7 = document.getElementById('beer_menu_sqr_brewery_text_7')
const beer_menu_sqr_brewery_text_8 = document.getElementById('beer_menu_sqr_brewery_text_8')

const beer_menu_sqr_style_text_1 = document.getElementById('beer_menu_sqr_style_text_1')
const beer_menu_sqr_style_text_2 = document.getElementById('beer_menu_sqr_style_text_2')
const beer_menu_sqr_style_text_3 = document.getElementById('beer_menu_sqr_style_text_3')
const beer_menu_sqr_style_text_4 = document.getElementById('beer_menu_sqr_style_text_4')
const beer_menu_sqr_style_text_5 = document.getElementById('beer_menu_sqr_style_text_5')
const beer_menu_sqr_style_text_6 = document.getElementById('beer_menu_sqr_style_text_6')
const beer_menu_sqr_style_text_7 = document.getElementById('beer_menu_sqr_style_text_7')
const beer_menu_sqr_style_text_8 = document.getElementById('beer_menu_sqr_style_text_8')

const beer_menu_abv_style_text_1 = document.getElementById('beer_menu_abv_style_text_1')
const beer_menu_abv_style_text_2 = document.getElementById('beer_menu_abv_style_text_2')
const beer_menu_abv_style_text_3 = document.getElementById('beer_menu_abv_style_text_3')
const beer_menu_abv_style_text_4 = document.getElementById('beer_menu_abv_style_text_4')
const beer_menu_abv_style_text_5 = document.getElementById('beer_menu_abv_style_text_5')
const beer_menu_abv_style_text_6 = document.getElementById('beer_menu_abv_style_text_6')
const beer_menu_abv_style_text_7 = document.getElementById('beer_menu_abv_style_text_7')
const beer_menu_abv_style_text_8 = document.getElementById('beer_menu_abv_style_text_8')

const beer_menu_ibu_style_text_1 = document.getElementById('beer_menu_ibu_style_text_1')
const beer_menu_ibu_style_text_2 = document.getElementById('beer_menu_ibu_style_text_2')
const beer_menu_ibu_style_text_3 = document.getElementById('beer_menu_ibu_style_text_3')
const beer_menu_ibu_style_text_4 = document.getElementById('beer_menu_ibu_style_text_4')
const beer_menu_ibu_style_text_5 = document.getElementById('beer_menu_ibu_style_text_5')
const beer_menu_ibu_style_text_6 = document.getElementById('beer_menu_ibu_style_text_6')
const beer_menu_ibu_style_text_7 = document.getElementById('beer_menu_ibu_style_text_7')
const beer_menu_ibu_style_text_8 = document.getElementById('beer_menu_ibu_style_text_8')

const beer_menu_sqr_03_text_1 = document.getElementById('beer_menu_sqr_03_text_1')
const beer_menu_sqr_05_text_1 = document.getElementById('beer_menu_sqr_05_text_1')
const beer_menu_sqr_03_text_2 = document.getElementById('beer_menu_sqr_03_text_2')
const beer_menu_sqr_05_text_2 = document.getElementById('beer_menu_sqr_05_text_2')
const beer_menu_sqr_03_text_3 = document.getElementById('beer_menu_sqr_03_text_3')
const beer_menu_sqr_05_text_3 = document.getElementById('beer_menu_sqr_05_text_3')
const beer_menu_sqr_03_text_4 = document.getElementById('beer_menu_sqr_03_text_4')
const beer_menu_sqr_05_text_4 = document.getElementById('beer_menu_sqr_05_text_4')
const beer_menu_sqr_03_text_5 = document.getElementById('beer_menu_sqr_03_text_5')
const beer_menu_sqr_05_text_5 = document.getElementById('beer_menu_sqr_05_text_5')
const beer_menu_sqr_03_text_6 = document.getElementById('beer_menu_sqr_03_text_6')
const beer_menu_sqr_05_text_6 = document.getElementById('beer_menu_sqr_05_text_6')
const beer_menu_sqr_03_text_7 = document.getElementById('beer_menu_sqr_03_text_7')
const beer_menu_sqr_05_text_7 = document.getElementById('beer_menu_sqr_05_text_7')
const beer_menu_sqr_03_text_8 = document.getElementById('beer_menu_sqr_03_text_8')
const beer_menu_sqr_05_text_8 = document.getElementById('beer_menu_sqr_05_text_8')

var data_columnB_tab_outter = sessionStorage.getItem("data_columnB_tab_out")
var data_columnC_tab_outter = sessionStorage.getItem("data_columnC_tab_out")
var data_columnD_tab_outter = sessionStorage.getItem("data_columnD_tab_out")
var data_columnE_tab_outter = sessionStorage.getItem("data_columnE_tab_out")
var data_columnF_tab_outter = sessionStorage.getItem("data_columnF_tab_out")
var data_columnG_tab_outter = sessionStorage.getItem("data_columnG_tab_out")
var data_columnH_tab_outter = sessionStorage.getItem("data_columnH_tab_out")

data_columnB_tab_outter = data_columnB_tab_outter.split(";,")
data_columnC_tab_outter = data_columnC_tab_outter.split(";,")
data_columnD_tab_outter = data_columnD_tab_outter.split(";,")
data_columnE_tab_outter = data_columnE_tab_outter.split(";,")
data_columnF_tab_outter = data_columnF_tab_outter.split(";,")
data_columnG_tab_outter = data_columnG_tab_outter.split(";,")
data_columnH_tab_outter = data_columnH_tab_outter.split(";,")

// console.log(data_columnB_tab_outter)
// console.log(data_columnC_tab_outter)
// console.log(data_columnD_tab_outter)
// console.log(data_columnE_tab_outter)
// console.log(data_columnF_tab_outter)
// console.log(data_columnG_tab_outter)
// console.log(data_columnH_tab_outter)

data_columnB_tab_outter[7] = data_columnB_tab_outter[7].substring(0, data_columnB_tab_outter[7].length - 1)
data_columnC_tab_outter[7] = data_columnC_tab_outter[7].substring(0, data_columnC_tab_outter[7].length - 1)
data_columnD_tab_outter[7] = data_columnD_tab_outter[7].substring(0, data_columnD_tab_outter[7].length - 1)
data_columnE_tab_outter[7] = data_columnE_tab_outter[7].substring(0, data_columnE_tab_outter[7].length - 1)
data_columnF_tab_outter[7] = data_columnF_tab_outter[7].substring(0, data_columnF_tab_outter[7].length - 1)
data_columnG_tab_outter[7] = data_columnG_tab_outter[7].substring(0, data_columnG_tab_outter[7].length - 1)
data_columnH_tab_outter[7] = data_columnH_tab_outter[7].substring(0, data_columnH_tab_outter[7].length - 1)

var data_table_ = [data_columnB_tab_outter , data_columnC_tab_outter , data_columnD_tab_outter , data_columnE_tab_outter , data_columnF_tab_outter , data_columnG_tab_outter , data_columnH_tab_outter]
// console.log(data_columnB_tab_outter)
// console.log(data_columnC_tab_outter)
// console.log(data_columnD_tab_outter)
// console.log(data_columnE_tab_outter)
// console.log(data_columnF_tab_outter)
// console.log(data_columnG_tab_outter)
// console.log(data_columnH_tab_outter)
// console.log(data_table_[0][1])
function beer_table_data(data_table_){
    beer_menu_sqr_name_text_1.textContent = data_table_[0][1]
    beer_menu_sqr_name_text_2.textContent = data_table_[0][2]
    beer_menu_sqr_name_text_3.textContent = data_table_[0][3]
    beer_menu_sqr_name_text_4.textContent = data_table_[0][4]
    beer_menu_sqr_name_text_5.textContent = data_table_[0][5]
    beer_menu_sqr_name_text_6.textContent = data_table_[0][6]
    beer_menu_sqr_name_text_7.textContent = data_table_[0][7]
    beer_menu_sqr_name_text_8.textContent = data_table_[0][8]
    beer_menu_sqr_brewery_text_1.textContent = data_table_[1][1]
    beer_menu_sqr_brewery_text_2.textContent = data_table_[1][2]
    beer_menu_sqr_brewery_text_3.textContent = data_table_[1][3]
    beer_menu_sqr_brewery_text_4.textContent = data_table_[1][4]
    beer_menu_sqr_brewery_text_5.textContent = data_table_[1][5]
    beer_menu_sqr_brewery_text_6.textContent = data_table_[1][6]
    beer_menu_sqr_brewery_text_7.textContent = data_table_[1][7]
    beer_menu_sqr_brewery_text_8.textContent = data_table_[1][8]
    beer_menu_sqr_style_text_1.textContent = data_table_[2][1]
    beer_menu_sqr_style_text_2.textContent = data_table_[2][2]
    beer_menu_sqr_style_text_3.textContent = data_table_[2][3]
    beer_menu_sqr_style_text_4.textContent = data_table_[2][4]
    beer_menu_sqr_style_text_5.textContent = data_table_[2][5]
    beer_menu_sqr_style_text_6.textContent = data_table_[2][6]
    beer_menu_sqr_style_text_7.textContent = data_table_[2][7]
    beer_menu_sqr_style_text_8.textContent = data_table_[2][8]
    beer_menu_abv_style_text_1.textContent = data_table_[3][1]
    beer_menu_abv_style_text_2.textContent = data_table_[3][2]
    beer_menu_abv_style_text_3.textContent = data_table_[3][3]
    beer_menu_abv_style_text_4.textContent = data_table_[3][4]
    beer_menu_abv_style_text_5.textContent = data_table_[3][5]
    beer_menu_abv_style_text_6.textContent = data_table_[3][6]
    beer_menu_abv_style_text_7.textContent = data_table_[3][7]
    beer_menu_abv_style_text_8.textContent = data_table_[3][8]
    beer_menu_ibu_style_text_1.textContent = data_table_[4][1]
    beer_menu_ibu_style_text_2.textContent = data_table_[4][2]
    beer_menu_ibu_style_text_3.textContent = data_table_[4][3]
    beer_menu_ibu_style_text_4.textContent = data_table_[4][4]
    beer_menu_ibu_style_text_5.textContent = data_table_[4][5]
    beer_menu_ibu_style_text_6.textContent = data_table_[4][6]
    beer_menu_ibu_style_text_7.textContent = data_table_[4][7]
    beer_menu_ibu_style_text_8.textContent = data_table_[4][8]
    beer_menu_sqr_03_text_1.textContent = data_table_[5][1]
    beer_menu_sqr_05_text_1.textContent = data_table_[6][1]
    beer_menu_sqr_03_text_2.textContent = data_table_[5][2]
    beer_menu_sqr_05_text_2.textContent = data_table_[6][2]
    beer_menu_sqr_03_text_3.textContent = data_table_[5][3]
    beer_menu_sqr_05_text_3.textContent = data_table_[6][3]
    beer_menu_sqr_03_text_4.textContent = data_table_[5][4]
    beer_menu_sqr_05_text_4.textContent = data_table_[6][4]
    beer_menu_sqr_03_text_5.textContent = data_table_[5][5]
    beer_menu_sqr_05_text_5.textContent = data_table_[6][5]
    beer_menu_sqr_03_text_6.textContent = data_table_[5][6]
    beer_menu_sqr_05_text_6.textContent = data_table_[6][6]
    beer_menu_sqr_03_text_7.textContent = data_table_[5][7]
    beer_menu_sqr_05_text_7.textContent = data_table_[6][7]
    beer_menu_sqr_03_text_8.textContent = data_table_[5][8]
    beer_menu_sqr_05_text_8.textContent = data_table_[6][8]
}
function table_template_name(data_table_){
    return`
                    <div class="beer_menu_sqr_name_column_1 beer_menu_sqr_name_column_">
                        <p class="beer_menu_sqr_name_text" id="beer_menu_sqr_name_text_1">${data_table_[0][0]}</p>
                        </div>
                    <div class="beer_menu_sqr_name_column_2 beer_menu_sqr_name_column_">
                        <p class="beer_menu_sqr_name_text" id="beer_menu_sqr_name_text_2">${data_table_[0][1]}</p>
                        </div>
                    <div class="beer_menu_sqr_name_column_3 beer_menu_sqr_name_column_">
                        <p class="beer_menu_sqr_name_text" id="beer_menu_sqr_name_text_3">${data_table_[0][2]}</p>
                        </div>
                    <div class="beer_menu_sqr_name_column_4 beer_menu_sqr_name_column_">
                        <p class="beer_menu_sqr_name_text" id="beer_menu_sqr_name_text_4">${data_table_[0][3]}</p>
                        </div>
                    <div class="beer_menu_sqr_name_column_5 beer_menu_sqr_name_column_">
                        <p class="beer_menu_sqr_name_text" id="beer_menu_sqr_name_text_5">${data_table_[0][4]}</p>
                        </div>
                    <div class="beer_menu_sqr_name_column_6 beer_menu_sqr_name_column_">
                        <p class="beer_menu_sqr_name_text" id="beer_menu_sqr_name_text_6">${data_table_[0][5]}</p>
                        </div>
                    <div class="beer_menu_sqr_name_column_7 beer_menu_sqr_name_column_">
                        <p class="beer_menu_sqr_name_text" id="beer_menu_sqr_name_text_7">${data_table_[0][6]}</p>
                        </div>
                    <div class="beer_menu_sqr_name_column_8 beer_menu_sqr_name_column_">
                        <p class="beer_menu_sqr_name_text" id="beer_menu_sqr_name_text_8">${data_table_[0][7]}</p>
                        </div>
    `
}
function table_template_brewery(data_table_){
    return`
                    <div class="beer_menu_sqr_brewery_column_1 beer_menu_sqr_brewery_column_">
                        <p class="beer_menu_sqr_brewery_text" id="beer_menu_sqr_brewery_text_1">${data_table_[1][0]}</p>
                        </div>
                    <div class="beer_menu_sqr_brewery_column_2 beer_menu_sqr_brewery_column_">
                        <p class="beer_menu_sqr_brewery_text" id="beer_menu_sqr_brewery_text_2">${data_table_[1][1]}</p>
                        </div>
                    <div class="beer_menu_sqr_brewery_column_3 beer_menu_sqr_brewery_column_">
                        <p class="beer_menu_sqr_brewery_text" id="beer_menu_sqr_brewery_text_3">${data_table_[1][2]}</p>
                        </div>
                    <div class="beer_menu_sqr_brewery_column_4 beer_menu_sqr_brewery_column_">
                        <p class="beer_menu_sqr_brewery_text" id="beer_menu_sqr_brewery_text_4">${data_table_[1][3]}</p>
                        </div>
                    <div class="beer_menu_sqr_brewery_column_5 beer_menu_sqr_brewery_column_">
                        <p class="beer_menu_sqr_brewery_text" id="beer_menu_sqr_brewery_text_5">${data_table_[1][4]}</p>
                        </div>
                    <div class="beer_menu_sqr_brewery_column_6 beer_menu_sqr_brewery_column_">
                        <p class="beer_menu_sqr_brewery_text" id="beer_menu_sqr_brewery_text_6">${data_table_[1][5]}</p>
                        </div>
                    <div class="beer_menu_sqr_brewery_column_7 beer_menu_sqr_brewery_column_">
                        <p class="beer_menu_sqr_brewery_text" id="beer_menu_sqr_brewery_text_7">${data_table_[1][6]}</p>
                        </div>
                    <div class="beer_menu_sqr_brewery_column_8 beer_menu_sqr_brewery_column_">
                        <p class="beer_menu_sqr_brewery_text" id="beer_menu_sqr_brewery_text_8">${data_table_[1][7]}</p>
                        </div>
    `
}
function table_template_style(data_table_){
    return`
                    <div class="beer_menu_sqr_style_column_1 beer_menu_sqr_style_column_">
                        <p class="beer_menu_sqr_style_text" id="beer_menu_sqr_style_text_1">${data_table_[2][0]}</p>
                        </div>
                    <div class="beer_menu_sqr_style_column_2 beer_menu_sqr_style_column_">
                        <p class="beer_menu_sqr_style_text" id="beer_menu_sqr_style_text_2">${data_table_[2][1]}</p>
                        </div>
                    <div class="beer_menu_sqr_style_column_3 beer_menu_sqr_style_column_">
                        <p class="beer_menu_sqr_style_text" id="beer_menu_sqr_style_text_3">${data_table_[2][2]}</p>
                        </div>
                    <div class="beer_menu_sqr_style_column_4 beer_menu_sqr_style_column_">
                        <p class="beer_menu_sqr_style_text" id="beer_menu_sqr_style_text_4">${data_table_[2][3]}</p>
                        </div>
                    <div class="beer_menu_sqr_style_column_5 beer_menu_sqr_style_column_">
                        <p class="beer_menu_sqr_style_text" id="beer_menu_sqr_style_text_5">${data_table_[2][4]}</p>
                        </div>
                    <div class="beer_menu_sqr_style_column_6 beer_menu_sqr_style_column_">
                        <p class="beer_menu_sqr_style_text" id="beer_menu_sqr_style_text_6">${data_table_[2][5]}</p>
                        </div>
                    <div class="beer_menu_sqr_style_column_7 beer_menu_sqr_style_column_">
                        <p class="beer_menu_sqr_style_text" id="beer_menu_sqr_style_text_7">${data_table_[2][6]}</p>
                        </div>
                    <div class="beer_menu_sqr_style_column_8 beer_menu_sqr_style_column_">
                        <p class="beer_menu_sqr_style_text" id="beer_menu_sqr_style_text_8">${data_table_[2][7]}</p>
                        </div>
    `
}
function table_template_abv(data_table_){
    return`
                    <div class="beer_menu_abv_style_column_1 beer_menu_abv_style_column_">
                        <p class="beer_menu_abv_style_text" id="beer_menu_abv_style_text_1">${data_table_[3][0]}</p>
                        </div>
                    <div class="beer_menu_abv_style_column_2 beer_menu_abv_style_column_">
                        <p class="beer_menu_abv_style_text" id="beer_menu_abv_style_text_2">${data_table_[3][1]}</p>
                        </div>
                    <div class="beer_menu_abv_style_column_3 beer_menu_abv_style_column_">
                        <p class="beer_menu_abv_style_text" id="beer_menu_abv_style_text_3">${data_table_[3][2]}</p>
                        </div>
                    <div class="beer_menu_abv_style_column_4 beer_menu_abv_style_column_">
                        <p class="beer_menu_abv_style_text" id="beer_menu_abv_style_text_4">${data_table_[3][3]}</p>
                        </div>
                    <div class="beer_menu_abv_style_column_5 beer_menu_abv_style_column_">
                        <p class="beer_menu_abv_style_text" id="beer_menu_abv_style_text_5">${data_table_[3][4]}</p>
                        </div>
                    <div class="beer_menu_abv_style_column_6 beer_menu_abv_style_column_">
                        <p class="beer_menu_abv_style_text" id="beer_menu_abv_style_text_6">${data_table_[3][5]}</p>
                        </div>
                    <div class="beer_menu_abv_style_column_7 beer_menu_abv_style_column_">
                        <p class="beer_menu_abv_style_text" id="beer_menu_abv_style_text_7">${data_table_[3][6]}</p>
                        </div>
                    <div class="beer_menu_abv_style_column_8 beer_menu_abv_style_column_">
                        <p class="beer_menu_abv_style_text" id="beer_menu_abv_style_text_8">${data_table_[3][7]}</p>
                        </div>
    `
}
function table_template_ibu(data_table_){
    return`
                    <div class="beer_menu_ibu_style_column_1 beer_menu_ibu_style_column_">
                        <p class="beer_menu_ibu_style_text" id="beer_menu_ibu_style_text_1">${data_table_[4][0]}</p>
                        </div>
                    <div class="beer_menu_ibu_style_column_2 beer_menu_ibu_style_column_">
                        <p class="beer_menu_ibu_style_text" id="beer_menu_ibu_style_text_2">${data_table_[4][1]}</p>
                        </div>
                    <div class="beer_menu_ibu_style_column_3 beer_menu_ibu_style_column_">
                        <p class="beer_menu_ibu_style_text" id="beer_menu_ibu_style_text_3">${data_table_[4][2]}</p>
                        </div>
                    <div class="beer_menu_ibu_style_column_4 beer_menu_ibu_style_column_">
                        <p class="beer_menu_ibu_style_text" id="beer_menu_ibu_style_text_4">${data_table_[4][3]}</p>
                        </div>
                    <div class="beer_menu_ibu_style_column_5 beer_menu_ibu_style_column_">
                        <p class="beer_menu_ibu_style_text" id="beer_menu_ibu_style_text_5">${data_table_[4][4]}</p>
                        </div>
                    <div class="beer_menu_ibu_style_column_6 beer_menu_ibu_style_column_">
                        <p class="beer_menu_ibu_style_text" id="beer_menu_ibu_style_text_6">${data_table_[4][5]}</p>
                        </div>
                    <div class="beer_menu_ibu_style_column_7 beer_menu_ibu_style_column_">
                        <p class="beer_menu_ibu_style_text" id="beer_menu_ibu_style_text_7">${data_table_[4][6]}</p>
                        </div>
                    <div class="beer_menu_ibu_style_column_8 beer_menu_ibu_style_column_">
                        <p class="beer_menu_ibu_style_text" id="beer_menu_ibu_style_text_8">${data_table_[4][7]}</p>
                        </div>
    `
}
function table_template_0305(data_table_){
    return`
    <div class="beer_menu_sqr_0305_column_1 beer_menu_sqr_0305_column_">
                        <div class="beer_menu_sqr_03_text beer_menu_sqr_03_text_1" >
                            <p id="beer_menu_sqr_03_text_1">${data_table_[5][0]}</p>
                        </div>
                        <div class="beer_menu_sqr_00_text beer_menu_sqr_00_text_1">———</div>
                        <div class="beer_menu_sqr_05_text beer_menu_sqr_05_text_1" >
                            <p id="beer_menu_sqr_05_text_1">${data_table_[6][0]}</p>
                        </div>
                        </div>
                    <div class="beer_menu_sqr_0305_column_2 beer_menu_sqr_0305_column_">
                        <div class="beer_menu_sqr_03_text beer_menu_sqr_03_text_2" >
                            <p id="beer_menu_sqr_03_text_2">${data_table_[5][1]}</p>
                        </div>
                        <div class="beer_menu_sqr_00_text beer_menu_sqr_00_text_2">———</div>
                        <div class="beer_menu_sqr_05_text beer_menu_sqr_05_text_2" >
                            <p id="beer_menu_sqr_05_text_2">${data_table_[6][1]}</p>
                        </div>
                        </div>
                    <div class="beer_menu_sqr_0305_column_3 beer_menu_sqr_0305_column_">
                        <div class="beer_menu_sqr_03_text beer_menu_sqr_03_text_3" >
                            <p id="beer_menu_sqr_03_text_3">${data_table_[5][2]}</p>
                        </div>
                        <div class="beer_menu_sqr_00_text beer_menu_sqr_00_text_3">———</div>
                        <div class="beer_menu_sqr_05_text beer_menu_sqr_05_text_3" >
                            <p id="beer_menu_sqr_05_text_3">${data_table_[6][2]}</p>
                        </div>
                        </div>
                    <div class="beer_menu_sqr_0305_column_4 beer_menu_sqr_0305_column_">
                        <div class="beer_menu_sqr_03_text beer_menu_sqr_03_text_4" >
                            <p id="beer_menu_sqr_03_text_4">${data_table_[5][3]}</p>
                        </div>
                        <div class="beer_menu_sqr_00_text beer_menu_sqr_00_text_4">———</div>
                        <div class="beer_menu_sqr_05_text beer_menu_sqr_05_text_4" >
                            <p id="beer_menu_sqr_05_text_4">${data_table_[6][3]}</p>
                        </div>
                        </div>
                    <div class="beer_menu_sqr_0305_column_5 beer_menu_sqr_0305_column_">
                        <div class="beer_menu_sqr_03_text beer_menu_sqr_03_text_5" >
                            <p id="beer_menu_sqr_03_text_5">${data_table_[5][4]}</p>
                        </div>
                        <div class="beer_menu_sqr_00_text beer_menu_sqr_00_text_5">———</div>
                        <div class="beer_menu_sqr_05_text beer_menu_sqr_05_text_5" >
                            <p id="beer_menu_sqr_05_text_5">${data_table_[6][4]}</p>
                        </div>
                        </div>
                    <div class="beer_menu_sqr_0305_column_6 beer_menu_sqr_0305_column_">
                        <div class="beer_menu_sqr_03_text beer_menu_sqr_03_text_6" >
                            <p id="beer_menu_sqr_03_text_6">${data_table_[5][5]}</p>
                        </div>
                        <div class="beer_menu_sqr_00_text beer_menu_sqr_00_text_6">———</div>
                        <div class="beer_menu_sqr_05_text beer_menu_sqr_05_text_6" >
                            <p id="beer_menu_sqr_05_text_6">${data_table_[6][5]}</p>
                        </div>
                        </div>
                    <div class="beer_menu_sqr_0305_column_7 beer_menu_sqr_0305_column_">
                        <div class="beer_menu_sqr_03_text beer_menu_sqr_03_text_7" >
                            <p id="beer_menu_sqr_03_text_7">${data_table_[5][6]}</p>
                        </div>
                        <div class="beer_menu_sqr_00_text beer_menu_sqr_00_text_7">———</div>
                        <div class="beer_menu_sqr_05_text beer_menu_sqr_05_text_7" >
                            <p id="beer_menu_sqr_05_text_7">${data_table_[6][6]}</p>
                        </div>
                        </div>
                    <div class="beer_menu_sqr_0305_column_8 beer_menu_sqr_0305_column_">
                        <div class="beer_menu_sqr_03_text beer_menu_sqr_03_text_8" >
                            <p id="beer_menu_sqr_03_text_8">${data_table_[5][7]}</p>
                        </div>
                        <div class="beer_menu_sqr_00_text beer_menu_sqr_00_text_8">———</div>
                        <div class="beer_menu_sqr_05_text beer_menu_sqr_05_text_8" >
                            <p id="beer_menu_sqr_05_text_8">${data_table_[6][7]}</p>
                        </div>
                        </div>
    `
}

function build_table(data_table_){
    if( typeof(data_table_)==="object"){
        beer_menu_sqr_name_column.insertAdjacentHTML('beforeend', table_template_name(data_table_))
        beer_menu_sqr_brewery_column.insertAdjacentHTML('beforeend', table_template_brewery(data_table_))
        beer_menu_sqr_style_column.insertAdjacentHTML('beforeend', table_template_style(data_table_))
        beer_menu_abv_style_column.insertAdjacentHTML('beforeend', table_template_abv(data_table_))
        beer_menu_ibu_style_column.insertAdjacentHTML('beforeend', table_template_ibu(data_table_))
        beer_menu_sqr_0305_column.insertAdjacentHTML('beforeend', table_template_0305(data_table_))
    }
}

// beer_table_data(data_table_)
function beer_table(){
    if(open_state === false){
        open_state = !open_state
        console.log(open_state)
        if(windowInnerWidth <= 400){
            beer_menu.style.height = `${925}px`
            beer_menu_sqr.style.height = `${870}px`

            beer_menu_sqr_snack.style.left = `${adapt_coeff}px`
            beer_menu_sqr_snack.style.width = `${prcnt_windowInnerWidth * 88.3}px`
            beer_menu_sqr_snack.style.height = `${420}px`
            
            beer_menu_sqr_snack_head.style.left = `${((prcnt_windowInnerWidth * 88.3) - 165)/2}px`
            
            beer_menu_sqr_snack_parent.style.left = `${((prcnt_windowInnerWidth * 88.3) - 320)/2}px`
            beer_menu_sqr_snack_parent.style.width = `${320}px`
            
            beer_menu_sqr_snack_child_1.style.width = `${320}px`
            beer_menu_sqr_snack_child_2.style.width = `${320}px`
            
            beer_menu_sqr_snack_sqr_factory_points_1.style.width = `${320}px`
            beer_menu_sqr_snack_sqr_factory_points_2.style.width = `${320}px`
            beer_menu_sqr_snack_sqr_factory_points_3.style.width = `${320}px`
            beer_menu_sqr_snack_sqr_factory_points_4.style.width = `${320}px`
            beer_menu_sqr_snack_sqr_factory_points_5.style.width = `${320}px`
            
            beer_menu_sqr_snack_sqr_factory_points_text_1.textContent = `● Арахис...................................`
            beer_menu_sqr_snack_sqr_factory_points_text_2.textContent = `● Арахис в оболочке............`
            beer_menu_sqr_snack_sqr_factory_points_text_3.textContent = `● Гренки.........................................`
            beer_menu_sqr_snack_sqr_factory_points_text_4.textContent = `● Вобла.......................................`
            beer_menu_sqr_snack_sqr_factory_points_text_5.textContent = `● Фисташки.................................`
            
            beer_menu_sqr_snack_sqr_craft_points_chesse_sub.style.width = `${250}px`
            
            beer_menu_sqr_snack_sqr_craft_points_1.style.width = `${320}px`
            beer_menu_sqr_snack_sqr_craft_points_2.style.width = `${320}px`
            beer_menu_sqr_snack_sqr_craft_points_3.style.width = `${320}px`
            
            beer_menu_sqr_snack_sqr_craft_points_chesse_sub_1.textContent = 'чечил................................'
            beer_menu_sqr_snack_sqr_craft_points_chesse_sub_2.textContent = 'шарики.............................'
            beer_menu_sqr_snack_sqr_craft_points_chesse_sub_3.textContent = 'бочонок.............................'
            beer_menu_sqr_button.style.top = `${790}px`
            coffe_menu_sqr_sirops_text.textContent = '↑свернуть↑'
            return
        }
        if((windowInnerWidth < 820) && (windowInnerWidth > 400)){
            beer_menu.style.height = `${925}px`
            beer_menu_sqr.style.height = `${870}px`

            beer_menu_sqr_snack.style.left = `${adapt_coeff}px`
            beer_menu_sqr_snack.style.width = `${prcnt_windowInnerWidth * 88.3}px`
            beer_menu_sqr_snack.style.height = `${420}px`
            
            beer_menu_sqr_snack_head.style.left = `${((prcnt_windowInnerWidth * 88.3) - 165)/2}px`

            beer_menu_sqr_snack_parent.style.left = `${((prcnt_windowInnerWidth * 88.3) - 365)/2}px`
            beer_menu_sqr_snack_parent.style.width = `${365}px`

            beer_menu_sqr_snack_child_1.style.width = `${365}px`
            beer_menu_sqr_snack_child_2.style.width = `${365}px`
            
            beer_menu_sqr_snack_sqr_factory_points_1.style.width = `${365}px`
            beer_menu_sqr_snack_sqr_factory_points_2.style.width = `${365}px`
            beer_menu_sqr_snack_sqr_factory_points_3.style.width = `${365}px`
            beer_menu_sqr_snack_sqr_factory_points_4.style.width = `${365}px`
            beer_menu_sqr_snack_sqr_factory_points_5.style.width = `${365}px`

            beer_menu_sqr_snack_sqr_craft_points_chesse_sub.style.width = `${290}px`

            beer_menu_sqr_snack_sqr_craft_points_1.style.width = `${360}px`
            beer_menu_sqr_snack_sqr_craft_points_2.style.width = `${360}px`
            beer_menu_sqr_snack_sqr_craft_points_3.style.width = `${360}px`

            beer_menu_sqr_button.style.top = `${790}px`
            coffe_menu_sqr_sirops_text.textContent = '↑свернуть↑'
            return
        }
        if(windowInnerWidth >= 820){
            beer_menu.style.height = `${775}px`
            beer_menu_sqr.style.height = `${720}px`

            beer_menu_sqr_snack.style.left = `${adapt_coeff}px`
            beer_menu_sqr_snack.style.height = `${275}px`
            beer_menu_sqr_snack.style.width = `${prcnt_windowInnerWidth * 88.3}px`

            beer_menu_sqr_snack_head.style.left = `${((prcnt_windowInnerWidth * 88.3) - 165)/2}px`

            beer_menu_sqr_snack_parent.style.width = `${prcnt_windowInnerWidth * 88.3}px`

            beer_menu_sqr_snack_child_2.style.top = `${0}px`
           
            beer_menu_sqr_button.style.top = `${640}px`
            
            coffe_menu_sqr_sirops_text.textContent = '↑свернуть↑'
            return
        }
    }
    if (open_state === true) {
        open_state = !open_state
        console.log(open_state)
        beer_menu.style.height = `${510}px`
        beer_menu_sqr.style.height = `${454}px`
        beer_menu_sqr_button.style.top = `${374}px`
        beer_menu_sqr_snack.style.height = `${0}px`
        coffe_menu_sqr_sirops_text.textContent = '↓к пиву↓'
        return
    }
}