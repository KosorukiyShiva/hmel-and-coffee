const coffe_menu_sqr_sirops = document.getElementById('coffe_menu_sqr_sirops')

coffe_menu_sqr_sirops.style.left = `${half_windowInnerWidth-130}px`
build_table(data_table_)
table_style(windowInnerWidth)
build_data_poster(data_xlsx_poster, quantity_of_poster_events_outter)